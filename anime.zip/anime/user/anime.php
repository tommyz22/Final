<?php

include("connection.php");


?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Anime</title>
	<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="assets/css/bootstrap.min.css"/>

		<link type="text/css" rel="stylesheet" href="assets/css/style.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">

</head>
<body>

	<?php

include("topnav.php")

?>
<div class="container">
					<div class="col-md-12">
						<div class="section-title">
							<div class="col-lg-6">
							<h3 class="title">Anime's List</h3><hr></div>
							<div class="section-nav">
								
								</ul>
							</div>
						</div>
					</div>
					</div>
<div class="container">
	<div class="row">
																					
			<?php
                      include('connection.php');
              $query="SELECT * FROM `anime`";
              $run=mysqli_query($con,$query);
  if (mysqli_num_rows($run)>0) {
  while($row=mysqli_fetch_array($run)){
   $id=$row['id'];
   $title=$row['title'];
   $name=$row['name'];
   $anime=$row['anime'];
   $thumbnail=$row['thumbnail'];
    $description=$row['description'];

                      ?>
                      
                      <div class="col-lg-4">
		<div class="product">
											<div class="product-img">
												<img src='../admin/<?php  echo $thumbnail   ?>' alt="">
												<div class="product-label">
													<span class="new">NEW</span>
												</div>
											</div>
											<div class="product-body">
	
												<h3 class="product-name"><a href="#"><?php echo $name  ?></a></h3>
												
												<div class="product-rating">
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
												</div>
												<div class="product-btns">
													<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
													<button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">add to compare</span></button>
													<button class="quick-view"><i class="fa fa-eye"></i><span class="tooltipp">quick view</span></button>
												</div>
											</div>
											<div class="add-to-cart">
											<a href="anime_detail.php?id=<?php echo $id; ?>">		<button class="add-to-cart-btn">
												
													<i class="fa fa-play"></i> Watch</button></a>
											</div>
										</div>
										</div>	
										
										<?php
                    }
                  }
                  ?>
			
			
	</div>

</div>
<div class="mb-5"></div>

<?php

include("footer.php")

?>

</body>
</html>