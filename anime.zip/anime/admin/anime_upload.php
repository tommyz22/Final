<?php 
session_start();
?>

<!DOCTYPE html>
<html lang="en">
	<head>
    <meta charset="utf-8">
	<title>Anime Upload</title>
	<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="assets/css/bootstrap.min.css"/>

		<link type="text/css" rel="stylesheet" href="assets/css/style.css"/>


	</head>
	<body>

		
        <div class="col-lg-4"></div>
        <div class="col-lg-4">
            
        <?php
 if (isset($_GET['success'])) {
          echo "<div class='alert alert-success'>File Uploaded</div>";
        }

         ?>
         <?php
        if (isset($_GET['error'])) {
          echo "<div class='alert alert-danger'>Files Not Uploaded</div>";
        }
?>
				<div class="container-fluid">

					<h3>Upload Anime Video</h3>
					<br>
					<form  action="operations.php" method="POST" enctype="multipart/form-data">
						<div class="form-group">
							<label>Title:</label>
							<input type="text" class="form-control form-control-lg" name="title" placeholder="Enter Video Title" required>
						</div>
                        <div class="form-group">
							<label>Name</label>
							<input type="text" class="form-control form-control-lg" name="name" placeholder="Enter Video Title" required>
						</div>
						<div class="form-group">
							<label>Anime Video File:</label>
							<input type="file" class="form-control form-control-lg" name="video_file" accept="video/*" required>
						</div>
						<div class="form-group">
							<label>Thumbnail</label>
							<input type="file" class="form-control" name="video_thumbnail" accept="image/*" required>
						</div>
						<div class="form-group">
							<label>Description:</label>
							<textarea rows="12" class="form-control" name="description" placeholder="Write description for your video..." required></textarea>
						</div>
						<hr>
						<div class="form-group">
							<input type="hidden" name="upload_video" value="">
							<button type="submit" class="btn btn-primary btn-lg" name="upload_video">Publish Video</button>
						</div>
					</form>
					<br><br>
				</div>
			</div>
			</div>
                
		
	</body>
	
	</script>
</html>
