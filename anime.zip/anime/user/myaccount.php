<!doctype html>
<html lang="en">
  <head>
    <title>My Profile</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/sidenav.css">
    <link rel="stylesheet" href="assets/owl-theme.css">
        
        <style>
          .profile-head {
    transform: translateY(5rem)
}

.cover {
    background-image: url(https://images.unsplash.com/photo-1530305408560-82d13781b33a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1352&q=80);
    background-size: cover;
    background-repeat: no-repeat
}

body {
    background: #654ea3;
    background: linear-gradient(to right, #e96443, #904e95);
    min-height: 100vh;
    overflow-x:hidden;
}
        </style>
</head>
  <body >
                    <!-- // Top  Nav Bar -->
  <?php
include 'topnav.php';
 
?>  

<?php
			
            
                include("connection.php");
                if (isset($_COOKIE['id']))
                {
                    
                    $uid= $_COOKIE['id'];
                    $email=mysqli_fetch_array(mysqli_query($con,"SELECT `email` FROM register WHERE id='$uid'"))[0];
                    $user_Name=mysqli_fetch_array(mysqli_query($con,"SELECT `username` FROM register WHERE id='$uid'"))[0];
                    $password=mysqli_fetch_array(mysqli_query($con,"SELECT `password` FROM register WHERE id='$uid'"))[0];

                    echo '<div class="row py-5 px-4"> <div class="col-md-5 mx-auto"> <!-- Profile widget --> 
                    <div class="bg-white shadow rounded overflow-hidden"> 
                       <div class="px-4 pt-0 pb-4 cover"> 
                         <div class="media align-items-end profile-head">
                            <div class="profile mr-3">
                              <img src="assets/img/avatar.png" alt="..." width="130" class="rounded mb-2 img-thumbnail">
                              ';
                             echo
                              '<a href="logout.php" class="btn btn-outline-danger btn-sm btn-block">Log out</a>';
                            echo ' </div> <div class="media-body mb-5 text-white"> <h4 class="mt-0 mb-0 text-light">';
                             echo $user_Name;
                            echo '</h4>'; 
                           echo '<p class="small mb-4">'; 
                         echo  $email;
                          echo '</p>'; 
                           echo '</div> </div> </div> <div class="bg-light p-4 d-flex justify-content-end text-center"> <ul class="list-inline mb-0"> <li class="list-inline-item"> </div> </div> </div> </div> </div>
                    </div>  ';
                     

                }

                else
                {
                 echo '<a href="login.php"><br><br><center><input type="submit" class="btn btn-lg btn-outline-success btn-lg btn-login text-uppercase font-weight-bold mt-5" value="Login"</a></center></div>';
                 echo '';
                }
                
			
		

?>
   



    


</div><br>

<?php  

include 'footer.php';
?>

    <script>
        function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
    </script>

</body>
</html>