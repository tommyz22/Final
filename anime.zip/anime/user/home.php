<?php
include("connection.php");
?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>Home</title>

		<!-- Bootstrap -->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    </head>
	<body>

<?php  include 'topnav.php'; ?>
	
	<div class="section">
		<div class="container">
			<div class="row">
				
				<div class="col-md-4 col-xs-6">
					<div class="shop">
						<div class="shop-img">
							<img src="assets/img/anime.png" width="470" height="300">
						</div>
						<div class="shop-body">
							<h3>Anime's<br>Collection</h3>
							<a href="anime.php" class="cta-btn">Watch now<i class="fa fa-arrow-circle-right"></i></a>
						</div>
					</div>
				</div>

				<div class="col-md-4 col-xs-6">
					<div class="shop">
						<div class="shop-img">
							<img src="assets/img/manga.png" width="470" height="300">
						</div>
						<div class="shop-body">
							<h3>Manga's<br>Collection</h3>
							<a href="manga.php" class="cta-btn">Read now <i class="fa fa-arrow-circle-right"></i></a>
						</div>
					</div>
				</div>

				<div class="col-md-4 col-xs-6">
					<div class="shop">
						<div class="shop-img">
							<img src="assets/img/comingsoon.png" width="470" height="300">
						</div>
						<div class="shop-body">
							<h3>coming soon</h3>
						</div>
					</div>
				</div>
			
			</div>
		</div>
	</div>


   
					










<?php  
include 'footer.php';
 ?>

	</body>
</html>
