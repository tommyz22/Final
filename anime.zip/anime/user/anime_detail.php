<?php
include("connection.php");
?>

<?php
 	include('connection.php');
    $id=$_GET['id'];
    $query="SELECT * FROM `anime` WHERE id='$id'";
    $run=mysqli_query($con,$query);
  	if (mysqli_num_rows($run)>0) {
		while($row=mysqli_fetch_array($run)){
		$id=$row['id'];
		$title=$row['title'];
		$name=$row['name'];
		$anime=$row['anime'];
		$thumbnail=$row['thumbnail'];
		$description=$row['description'];
		}
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title><?php echo $name ?></title>

 	<!-- Bootstrap -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>



</head>

<body>

<?php
include("../user/topnav.php")
?>

<div id="breadcrumb" class="section">
			<!-- container -->
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h3 class="breadcrumb-header">Anime</h3>
					<ul class="breadcrumb-tree">
						<li><p>Watch</p></li>
						<li class="active"><?php echo $name ?></li>
					</ul>
			</div>
		</div>
	</div>
</div>

<div class="container">
       
	   <?php 
        include("connection.php");
        $query="SELECT * FROM `anime` WHERE id='$id'";
        $run=mysqli_query($con,$query);
        if (mysqli_num_rows($run)>0){
        	while ($row=mysqli_fetch_array($run)){
            $id=$row['id'];
			$title=$row['title'];
			$name=$row['name'];
			$anime=$row['anime'];
			$thumbnail=$row['thumbnail'];
    		$description=$row['description'];
    		}
		}
		?>

		<div class="col-lg-12">
			<div class="product">
				<div class="product-img">
                   <video src="../admin/<?php echo $anime ?>" width="100%" height="100%" controls></video>
				</div>
			</div>
		</div>

	<div class="col-lg-12">
		<div class="product">
			<div class="product-body">
				<h3 class="product-name"><a href="#"><?php echo $name  ?></a></h3>
												
				<div class="product-rating">
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
				</div>

				<div class="product-btns">
					<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
					<button class="quick-view"><i class="fa fa-eye"></i><span class="tooltipp">already seen</span></button>
				</div><hr>
				<strong>Description</strong><br>
				<span><?php  echo $description ?></span>
	
			</div>
		</div>
	</div>

</div>

<?php
include("footer.php");
?>

</body>
</html>