<?php
include('include/connection.php');
setcookie("email","$email",time()-3600,"/");
setcookie("id", "", time() - 3600,"/");

//clear cookie

header('Location: home.php');
?>
<script>
window.location.href='home.php';
</script>


?>