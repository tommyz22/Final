<!doctype html>
<html lang="en">
  <head>
    <title>About Us</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Bootstrap -->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    
    <link rel="stylesheet" href="assets/sidenav.css">

</head>

<body class="bg-white">

<!-- // Top  Nav Bar -->

    <?php
    include 'topnav.php';
    ?>

<br><br>

    <div class="container">
            <div class="row">
                <div class="col-lg-12 mx-auto bg-light p-5 rounded mt-3">
                   <center><h2 class="">ABOUT US </h2></center>
                   <center><h3 class="text-success"> *About Tom </h3></center>
                   <center><p>"A Website To Watch Anime And Read Manga"</p></center><br>
                   <p> I should write in here but I don't know what to write </p>
                   <p> My name is Tommaso and I'm 19 years old and I'm always bored</p>
            </div>
        </div>
</div>
<br>

<?php include'footer.php';  ?>
<?php include'script.php';  ?>
    <script>
  function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
    </script>

</body>
</html>