
<section class="footer pt-5 pb-5 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-12 col-sm-12">
            </div>
            <div class="col-md-4 col-12 col-sm-12">
            </div>
            <div class="col-md-1 col-sm-6 mobile-none">
            </div>
            <div class="col-md-2 col-4 col-sm-4">
                <h6 class="mb-3">Infos</h6>
                <ul>
                    <li><a href="aboutus.php">About Us</a></li>
                    <li><a href="myaccount.php">My Account</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<footer class="pt-4 pb-4 text-center">
    <div class="container">
        <small class="mt-0 mb-0">Made By Tom</small>
    </div>
</footer>
