<?php session_start();?>
<?php
	include "connection.php";
	
	if (isset($_POST['signup_user'])) 
        {
        $user_name=$_POST['username'];
        $email=$_POST['email'];
        $password=$_POST['password'];    
        if (empty($user_name)||empty($email)||empty($password)) 
        {
            header("location:register.php?message=1");
        }
          $sql="SELECT * FROM register where (email='$email');";
        $res=mysqli_query($con,$sql);
      if (mysqli_num_rows($res) > 0) {
        
        $row = mysqli_fetch_assoc($res);
        if($email==isset($row['email']))
        {
              // echo "email already exists";
            header("location:register.php?error=1");


        }
    }



        else{ 
        $query="INSERT INTO `register`(`username`, `email`, `password`) VALUES ('$user_name','$email','$password')";
        $run=mysqli_query($con,$query);
        if (!$run) 
        {
           echo "Try Again Unkown Error Occur";
        }
        else
        {
           $redirect = "login.php";
			header("location:$redirect");
			echo "<script> window.location.href = '$redirect' </script>";
			exit();
        }
        
        }
        
        }
	
	 
   
        if (isset($_POST['login_user']))
    {       
        $email=$_POST['email'];
        $password=$_POST['password'];
        $query="SELECT * FROM `register` WHERE email='$email' and password='$password'";
      $run=mysqli_query($con,$query);
      if (mysqli_num_rows($run)>0) 
      {
          $uid=mysqli_fetch_array($run)[0];  

      setcookie("id","$uid",time()+3600,"/");
      setcookie("email","$email",time()+3600,"/");

      header("location:myaccount.php");      
      }     
      else{

      $message = '<div class="alert alert-danger" role="alert">Wrong Password</div>';
      header("location:login.php?message=1");
  } 
  }

    if (isset($_POST['contact_us'])) 
        {
        $name=$_POST['name'];
        $email=$_POST['email'];
        $message=$_POST['message'];      
        if (empty($name)||empty($email)||empty($message)) 
        {
            header("location:contactus.php?message=1");
        }
        else{ 
        $query="INSERT INTO `contact_us`(`Name`, `Email`, `message`) VALUES ('$name','$email','$message')";
        $run=mysqli_query($con,$query);
        if (!$run) 
        {
           echo "Try Again Unkown Error Occur";
        }
        else
        {
                      header("location:contactus.php?success=1");

      exit();
      }
    }
  }




?>