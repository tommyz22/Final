<?php

    include 'connection.php';

        if (isset($_POST["upload_video"])) 
        {
            $title = mysqli_real_escape_string($con, $_POST["title"]);
            $description = mysqli_real_escape_string($con, $_POST["description"]);
            $name = mysqli_real_escape_string($con, $_POST["name"]);
            $video_file='files/'.$_FILES['video_file']['name'];
                move_uploaded_file($_FILES['video_file']['tmp_name'],$video_file);
                $video_thumbnail='files/'.$_FILES['video_thumbnail']['name'];
                move_uploaded_file($_FILES['video_thumbnail']['tmp_name'],$video_thumbnail);
        
		$query="INSERT INTO `anime`(`title`, `name`, `anime`, `thumbnail`, `description`) VALUES ('$title','$name','$video_file','$video_thumbnail','$description')";
        $run=mysqli_query($con,$query);
        if(!$run)
        {
            header("location:anime_upload.php?error=1");
        }
        else
        {
            header("location:anime_upload.php?success=1");
        }	
		
	}

    if (isset($_POST["upload_manga"])) 
    {
        $title = mysqli_real_escape_string($con, $_POST["title"]);
        $description = mysqli_real_escape_string($con, $_POST["description"]);
        $name = mysqli_real_escape_string($con, $_POST["name"]);
        $manga_file='files/'.$_FILES['manga_file']['name'];
            move_uploaded_file($_FILES['manga_file']['tmp_name'],$manga_file);
            $manga_thumbnail='files/'.$_FILES['manga_thumbnail']['name'];
            move_uploaded_file($_FILES['manga_thumbnail']['tmp_name'],$manga_thumbnail);
    
    $query="INSERT INTO `manga`(`Title`, `name`, `manga`, `thumbnail`, `description`) VALUES ('$title','$name','$manga_file','$manga_thumbnail','$description')";
    $run=mysqli_query($con,$query);
    if(!$run)
    {
        header("location:manga_upload.php?error=1");
    }
    else
    {
        header("location:manga_upload.php?success=1");
    }	
    
}




















?>