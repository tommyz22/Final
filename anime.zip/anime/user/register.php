<!doctype html>
<html lang="en">
  <head>
    <title>Register</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="assets/sidenav.css">
</head>
  <body class="bg-white">
                    <!-- // Top  Nav Bar -->
  <?php
include 'topnav.php';

  ?>
     <!-- // End Top Nav -->
      <div class="container-fluid">
        <div class="row no-gutter">
            <div class="d-none d-md-flex col-md-4 col-lg-6 "></div>
            <div class="col-md-8 col-lg-6">
                <div class="login d-flex align-items-center py-5">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-9 col-lg-8 mx-auto pl-5 pr-5">
                                <?php
        if (isset($_GET['message'])) {
          echo "<div class='alert alert-danger'>Kindly Fill All Fileds</div>";
        }

         ?>
         <?php
        if (isset($_GET['error'])) {
          echo "<div class='alert alert-danger'>Email Already Exists</div>";
        }

         ?>
                                <h3 class="login-heading mb-4">Hey New Buddy...!</h3>
                                <form action="operations" method="POST" autocomplete="off">
                                  
                                    <div class="form-label-group mb-4">
                                        <input type="text" id="ptext" class="form-control" placeholder="Enter Your Name" name="username" >
                                        <label for="ptext">Name</label>
                                    </div>
                                    <div class="form-label-group">
                                        <input type="email" id="inputEmail" class="form-control"
                                            placeholder="Email address" name="email" >
                                        <label for="inputEmail">Email address</label>
                                        
                                    </div>
                                    <div class="form-label-group">
                                        <input type="password" id="inputPassword" class="form-control"
                                            placeholder="Password" name="password"  >
                                        <label for="inputPassword">Password</label>
                                        
                                    </div>
                                    
                                    
                                    <input type="submit"
                                        class="btn btn-lg btn-outline-warning bg-black btn-block btn-login text-uppercase font-weight-bold mb-2" name="signup_user" value="Register Now">
                                    <div class="text-center pt-3">
                                        Already have an Account? <a class="font-weight-bold" href="login">Sign
                                            In</a>
                                    </div>
                                    <hr class="my-4">
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php
 include'script.php';
  ?>
<?php 
include'footer.php.php';
  ?>

    <script>
        function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
    </script>

</body>
</html>