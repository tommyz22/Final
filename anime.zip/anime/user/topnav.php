<!doctype html>
<html lang="en">
  <head>
    <title>Mangalist</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/sidenav.css">
    <link rel="stylesheet" href="assets/owl-theme.css">
    
    <style type="text/css">
            input[type=file]::file-selector-button {
  border: 2px solid #6c5ce7;
  padding: .2em .4em;
  border-radius: .2em;
  background-color: #FFBA01;
  transition: 1s;
}
        </style>
<style type="text/css">
  .bg-black {
    background-color: #3b3939 !important;
    /* border-color: #3ecf8e !important; */
}
.card{
    border-radius: 4px;
    background: #fff;
    box-shadow: 0 6px 10px rgba(0,0,0,.08), 0 0 6px rgba(0,0,0,.05);
      transition: .3s transform cubic-bezier(.155,1.105,.295,1.12),.3s box-shadow,.3s -webkit-transform cubic-bezier(.155,1.105,.295,1.12);
  padding: 14px 80px 18px 36px;
  cursor: pointer;
}

.card:hover{
     transform: scale(1.05);
  box-shadow: 0 10px 20px rgba(0,0,0,.12), 0 4px 8px rgba(0,0,0,.06);
}

.card h3{
  font-weight: 600;
}

.card img{
  position: absolute;
  top: 20px;
  right: 15px;
  max-height: 120px;
}

.card-1{
  background-image: url(https://ionicframework.com/img/getting-started/ionic-native-card.png);
      background-repeat: no-repeat;
    background-position: right;
    background-size: 80px;
}

.card-2{
   background-image: url(https://ionicframework.com/img/getting-started/components-card.png);
      background-repeat: no-repeat;
    background-position: right;
    background-size: 80px;
}

.card-3{
   background-image: url(https://ionicframework.com/img/getting-started/theming-card.png);
      background-repeat: no-repeat;
    background-position: right;
    background-size: 80px;
}

@media(max-width: 990px){
  .card{
    margin: 20px;
  }
} 
</style>
</head>
  <body >
  <div class="homepage-header">

    <nav class="navbar navbar-expand-lg navbar-light bg-warning">
  <a class="navbar-brand" href="home.php"><h2 class="ml-5 mt-2 text-light foont">Manga-List</h2></a>
  </button>
    
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    
            <div class="container">
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                   
                <ul class="navbar-nav ml-auto">
                <?php

            if(!isset($_COOKIE['id']))
            {

            ?>
            
                   <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="myaccount.php" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                 Search
                            </a>
                            <div class="dropdown-menu dropdown-menu-right shadow-sm border-0">
                                <a class="dropdown-item" href="myaccount.php"><i class="fa fa-play" aria-hidden="true"></i> <b class="ml-2">Anime</b></a>
                                <a class="dropdown-item" href="myaccount.php"><i class="fa fa-book" aria-hidden="true"></i><b class="ml-2">Manga</b></a>
                            </div>
                            
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="aboutus.php"><i class="icofont-sale-discount"></i> About Us
                                <span class=""></span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php"><i class="icofont-sale-discount"></i> Login
                                <span class=""></span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href=""><i class="icofont-sale-discount"></i> /
                                <span class=""></span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="register.php"><i class="icofont-sale-discount"></i> Register
                                <span class=""></span></a>
                        </li>
                        <?php 
                         }
                         else{                       
                          ?>
                         <li class="nav-item">
                            <a class="nav-link" href="home.php"><i class="icofont-sale-discount"></i> Home
                                <span class=""></span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="anime.php"><i class="icofont-sale-discount"></i> Anime List
                                <span class=""></span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manga.php"><i class="icofont-sale-discount"></i> Manga List
                                <span class=""></span></a>
                        </li>
                       
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="myaccount.php" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <img alt="Generic placeholder image" src="assets/img/avatar.png"
                                    class="nav-osahan-pic rounded-pill"> MY ACCOUNT
                            </a>
                            <div class="dropdown-menu dropdown-menu-right shadow-sm border-0">
                                <a class="dropdown-item" href="myaccount.php">My Profile</a>
                                <a class="dropdown-item" href="logout.php">Logout</a>
                            </div>
                        </li>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <?php
                        }
                        ?>
                        
                        
                        
                       
                        
                    </ul>
                </div>
            </div>
    </div>
</nav>





    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script>
        function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
    </script>

</body>
</html>