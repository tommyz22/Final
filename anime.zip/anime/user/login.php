<!doctype html>
<html lang="en">
<head>
    <title>Login</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Bootstrap -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    
    <link rel="stylesheet" href="assets/sidenav.css">

</head>

<body class="bg-white">

<?php
include 'topnav.php';
?>

    <div class="container-fluid">
        <div class="row no-gutter">

            <div class="d-none d-md-flex col-md-4 col-lg-6 ">
            </div>

            <div class="col-md-8 col-lg-6">
                <div class="login d-flex align-items-center py-5">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-9 col-lg-8 mx-auto pl-5 pr-5" >

                                <?php
                                    if (isset($_GET['message'])) {
                                        echo "<div class='alert alert-danger'>Please Enter Valid Email & Password</div>";
                                    }
                                ?>

                                <h3 class="login-heading mb-4">Welcome back!</h3>

                                <form action="operations.php" method="POST" autocomplete="off">
                                    <div class="form-label-group">
                                        <input type="email" id="inputEmail" class="form-control" placeholder="Email address" name="email" >
                                        <label for="inputEmail">Email address</label>
                                        <span id="error1"></span>
                                    </div>
                                    <div class="form-label-group">
                                        <input type="password" id="inputPassword" class="form-control"
                                            placeholder="Password" name="password">
                                        <label for="inputPassword">Password</label>
                                         <span id="error2"></span>
                                    </div>

                                    <a href="myaccount.php?id=<?php echo $id ?>">
                                    <input type="submit" class="btn btn-lg btn-outline-warning bg-black btn-block btn-login text-uppercase font-weight-bold mb-2" value="Sign in" name="login_user" ></a>
                                    <div class="text-center pt-3"> Don’t have an account? <a class="font-weight-bold" href="register.php">Sign Up</a>
                                    </div>
                                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>



<script type="text/javascript">
            function validate(){
                var email=document.getElementById('email').value;
                var password=document.getElementById('password').value;
                if (email=="") {
                    document.getElementById('email').style="border:0.5px solid red";
                    document.getElementById('error1').innerHTML="Enter the Email";
                }
                if (password=="") {
                    document.getElementById('password').style="border:0.5px solid red";
                    document.getElementById('error2').innerHTML= "Enter  the Password";
                }
            }
</script>



<?php
include("footer.php");
?>

    <script>
        function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
    </script>

</body>
</html>